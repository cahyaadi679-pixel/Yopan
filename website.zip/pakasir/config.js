// Konfigurasi untuk Pakasir & Pterodactyl
// Disarankan isi via environment variable di Vercel,
// tapi kalau mau hardcode pastikan file ini tidak di-publish ke repo publik.

module.exports = {
  // Pakasir
  PAKASIR_PROJECT: process.env.PAKASIR_PROJECT || "newproject",
  PAKASIR_API_KEY: process.env.PAKASIR_API_KEY || "AsyIISrYJ67r9M8ZAAE33n5XvWaI9Fa9",
  IS_SANDBOX: process.env.PAKASIR_SANDBOX === "false",

  // Pterodactyl
  PTERO_EGG: process.env.PTERO_EGG || "15",
  PTERO_NEST_ID: process.env.PTERO_NEST_ID || "5",
  PTERO_LOC: process.env.PTERO_LOC || "1",
  PTERO_DOMAIN: process.env.PTERO_DOMAIN || "https://alpha-premier.privatserver.my.id",
  PTERO_API_KEY: process.env.PTERO_API_KEY || "ptla_5oEDSwf1GFSvI5tQ4UU717QDy295AB071KVLPwTBpP2",
  PTERO_CLIENT_KEY: process.env.PTERO_CLIENT_KEY || "ptlc_tw8O2cKsga7ym8pP3vDZe5K67Z9pifguRMNDOZ9bBcl"
};
