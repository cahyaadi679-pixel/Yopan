window.APP_CONFIG = {
  apiBaseUrl: "/api",
  currencyPrefix: "Rp",
  currencySuffix: "/bulan"
};
